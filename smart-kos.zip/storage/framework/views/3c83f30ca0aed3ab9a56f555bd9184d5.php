
<div class="col-xl col-lg">
    <div class="card shadow mb-4">
        <div class="card-body">
            <div>
                <div class="pb-2">
                    <h2>Riwayat</h2>
                </div>
                <div class="pb-2">
                    <!--[if BLOCK]><![endif]--><?php if($mode == 1): ?>
                        <button wire:click="selectMode(0, 0)" type="button" class="btn btn-secondary">Kembali</button>
                    <?php elseif($mode == 2): ?>
                        <button wire:click="selectMode(1, <?php echo e($selectedYear); ?>)" type="button" class="btn btn-secondary">Kembali</button>
                    <?php elseif($mode == 3): ?>
                        <button wire:click="selectMode(2, <?php echo e($selectedMonth); ?>)" type="button" class="btn btn-secondary">Kembali</button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="pb-2">
                    <h5 wire:loading>
                        Memproses data...
                    </h5>
                </div>
            </div>
            <form wire:loading.remove>
                <table class="table table-hover">
                    <!--[if BLOCK]><![endif]--><?php if($homeView == true): ?>
                        <thead>
                            <th scope="col">No.</th>
                            <th scope="col">Kos</th>
                            <th scope="col">Admin</th>
                            <th scope="col">Kamar</th>
                            <th scope="col">Lihat</th>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php if($manyRoom): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $manyRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item+1); ?></td>
                                    <td><?php echo e($value['kos']); ?></td>
                                    <td><?php echo e($value['admin']); ?></td>
                                    <td><?php echo e($value['name']); ?></td>
                                    <td>
                                        <button wire:click="roomDetail(<?php echo e($value['id']); ?>, false)" type="button" class="btn btn-primary">Lihat</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                            <tr>
                                Data masih kosong
                            </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    <?php else: ?>
                        <div class="row">
                            <label class="col-sm-1">Kos</label>
                            <div class="col">
                                : <?php echo e($kosName); ?>

                            </div>
                        </div>
                        <div class="row">
                            <label class="col-sm-1">Kamar</label>
                            <div class="col">
                                : <?php echo e($roomName); ?>

                            </div>
                        </div>
                        <thead>
                            <tr>
                                <th scope="col">No.</th>
                                <th scope="col">Waktu</th>
                                <th scope="col">Tarif</th>
                                <th scope="col">KWh</th>
                                <th scope="col">Tagihan</th>
                                <!--[if BLOCK]><![endif]--><?php if($mode == 1): ?>
                                    <th scope="col">Status</th>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php if($mode == 0): ?>
                                <!--[if BLOCK]><![endif]--><?php for($i=0; $i<$totalYear; $i++): ?>
                                    <tr>
                                        <td class="text-left">
                                            <?php echo e($i+1); ?>

                                        </td>
                                        <td class="text-left">
                                            <?php echo e($manyYear[$i]); ?>

                                        </td>
                                        <td class="text-left">
                                            Rp
                                            <?php echo e(number_format($roomTariff[$i], 2, ',', '.')); ?>

                                        </td>
                                        <td class="text-left">
                                            
                                                <?php echo e(floatval($yearlyKwh[$i])); ?>

                                            
                                            Kwh
                                        </td>
                                        <td class="text-left">
                                            Rp
                                            <?php echo e(number_format($yearlyBill[$i], 2, ',', '.')); ?>

                                        </td>
                                        <td class="text-left">
                                            <button wire:click="selectMode(1, <?php echo e($manyYear[$i]); ?>)" type="button" class="btn btn-primary">Lihat</button>
                                        </td>
                                    </tr>
                                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-left">
                                            <?php echo e($data+1); ?>

                                        </td>
                                        <td class="text-left">
                                            <?php echo e($value); ?>

                                        </td>
                                        <td class="text-left">
                                            Rp
                                            <?php echo e(number_format($selectedTariff[$data], 2, ',', '.')); ?>

                                        </td>
                                        <td class="text-left">
                                            <!--[if BLOCK]><![endif]--><?php if(strlen($selectedKwh[$data]) > 5): ?>
                                                <?php echo e(number_format($selectedKwh[$data], 6, ',', '.')); ?>

                                            <?php else: ?>
                                                <?php echo e(floatval($selectedKwh[$data])); ?>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            Kwh
                                        </td>
                                        <td class="text-left">
                                            Rp
                                            <?php echo e(number_format($selectedBill[$data], 2, ',', '.')); ?>

                                        </td>
                                        <!--[if BLOCK]><![endif]--><?php if($mode == 1): ?>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($selectedStatus[$data] === 0): ?>
                                                    <button class="btn btn-sm btn-outline-danger" disabled>Belum bayar</button>
                                                <?php elseif($selectedStatus[$data] === null): ?>
                                                    <button class="btn btn-sm btn-outline-secondary" disabled>Bulan ini</button>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-outline-success" disabled>Sudah bayar</button>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <td class="text-left">
                                            <!--[if BLOCK]><![endif]--><?php if($mode == 1): ?>
                                                <button wire:click="selectMode(2, <?php echo e((int)$value); ?>)" type="button" class="btn btn-primary">Lihat</button>
                                            <?php elseif($mode == 2): ?>
                                                <button wire:click="selectMode(3, <?php echo e((int)$value); ?>)" type="button" class="btn btn-primary">Lihat</button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </table>
                <!--[if BLOCK]><![endif]--><?php if($mode != 0): ?>
                    <button wire:click="selectMode(0, 0)" type="button" class="btn btn-secondary">Kembali ke Tahun</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php if($homeView == false): ?>
                    <button wire:click="roomDetail(0, true)" type="button" class="btn btn-secondary">Kembali ke Kos</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\smart-kos\resources\views/livewire/history.blade.php ENDPATH**/ ?>