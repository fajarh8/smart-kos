<div class="container py-5">
    <div class="w-50 center border rounded px-3 py-3 mx-auto">
    <h1>Login</h1>
    <!--[if BLOCK]><![endif]--><?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('loginError')): ?>
        <div class="pt-3">
            <div class="alert alert-danger">
                <?php echo e(session('loginError')); ?>

            </div>
        </div>
    <?php elseif(session()->has('createSuccess')): ?>
        <div class="pt-3">
            <div class="alert alert-success">
                <?php echo e(session('createSuccess')); ?>

            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <form action="">
        <?php echo csrf_field(); ?>
        <!--[if BLOCK]><![endif]--><?php if($create == true): ?>
            <div class="mb-3">
                <label for="email" class="form-label">Nama</label>
                <input type="name" wire:model="name" name="name" class="form-control">
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" wire:model="email" name="email" class="form-control">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" wire:model="password" name="password" class="form-control">
        </div>
        <!--[if BLOCK]><![endif]--><?php if($create == true): ?>
            <div class="mb-3">
                <label for="password_confirmation" class="form-label">Konfirmasi password</label>
                <input type="password" wire:model="password_confirmation" name="password_confirmation" class="form-control">
            </div>
            
            <div class="mb-3">
                <label class="form-label" for="inlineFormCustomSelect">Role</label>
                <select wire:model="role" class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="mb-3 d-grid">
        <!--[if BLOCK]><![endif]--><?php if($create == false): ?>
            <button wire:click="loginUser()" name="submit" type="button" class="btn btn-primary btn-block">Login</button>
            <div class="pt-3 text-center">
                <label for="changeMode">Belum punya akun?</label>
                <button id="changeMode" wire:click="createAccount(true)" name="submit" type="button" class="btn btn-link">Buat akun</button>
            </div>
        <?php elseif($create == true): ?>
            <button wire:click="submitCreate()" name="submit" type="button" class="btn btn-primary btn-block">Buat Akun</button>
            <div class="pt-3 text-center">
                <label for="changeMode">Sudah punya akun?</label>
                <button id="changeMode" wire:click="createAccount(false)" name="submit" type="button" class="btn btn-link">Login</button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </form>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\smart-kos\resources\views/livewire/login.blade.php ENDPATH**/ ?>