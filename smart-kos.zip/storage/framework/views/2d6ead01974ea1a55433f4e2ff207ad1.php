<div>
    <h1>Hello from Livewire</h1>
</div>
<?php /**PATH C:\xampp\htdocs\smart-kos\resources\views/livewire/admin.blade.php ENDPATH**/ ?>