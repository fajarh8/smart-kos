<div class="container h-100 w-100">
    <!--[if BLOCK]><![endif]--><?php if($deviceConnected == true): ?>
        <div class="card shadow mb-4">
            <div class="p-4">
                <h2>Relay</h2>
                <table class="table table-lg table-hover">
                    <thead>
                        <tr>
                            <th scope="col" class="col-md-0 text-center">No.</th>
                            <th scope="col" class="col-md-5 text-left">Nama Perangkat</th>
                            <th scope="col" class="col-md-1 text-center">Automasi</th>
                            <th scope="col" class="col-md-1 text-center">PIR</th>
                            <th scope="col" class="col-md-1 text-center">Jenis</th>
                            <th scope="col" class="col-md-2 text-center">ON</th>
                            <th scope="col" class="col-md-2 text-center">OFF</th>
                            <th scope="col" class="col-md-1 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php for($i=0; $i<6; $i++): ?>
                            <tr id="hoverMe">
                                <td class="text-center"><?php echo e($i + 1); ?></td>
                                <td class="text-left">
                                    <?php echo e($label[$i]); ?>

                                </td>
                                <td class="text-center">
                                    <!--[if BLOCK]><![endif]--><?php if($type[$i] != null): ?>
                                        <label class="switch mt-2" wire:click="autoSwitch(<?php echo e($i); ?>)">
                                            <input wire:click="autoSwitch(<?php echo e($i); ?>)" type="checkbox" <?php echo e($automation[$i] ? "checked" : ""); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td class="text-center">
                                    <label class="switch mt-2">
                                        <input wire:click="pirSwitch(<?php echo e($i); ?>)" type="checkbox" <?php echo e($pirAuto[$i] ? "checked" : ""); ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                                <td class="text-center">
                                    <!--[if BLOCK]><![endif]--><?php switch($type[$i]):
                                        case (2): ?>
                                            Suhu
                                            <?php break; ?>
                                        <?php case (3): ?>
                                            Cahaya
                                            <?php break; ?>
                                        <?php case (1): ?>
                                            Waktu
                                            <?php break; ?>
                                        <?php default: ?>
                                    <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td class="text-center">
                                    <?php if($type[$i] != 2 && $type[$i] != 3): ?>
                                        <?php echo e($onTime[$i]); ?>

                                    <?php elseif($type[$i] == 2): ?>
                                        >= <?php echo e($tempThreshold[$i]); ?>°C
                                    <?php elseif($type[$i] == 3): ?>
                                        < <?php echo e($ldrThreshold[$i]); ?>%
                                    <?php else: ?>
                                        -
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td class="text-center">
                                    <!--[if BLOCK]><![endif]--><?php if($type[$i] != 2 && $type[$i] != 3): ?>
                                        <?php echo e($offTime[$i]); ?>

                                    <?php elseif($type[$i] == 2): ?>
                                        < <?php echo e($tempThreshold[$i]); ?>°C
                                    <?php elseif($type[$i] == 3): ?>
                                        >= <?php echo e($ldrThreshold[$i]); ?>%
                                    <?php else: ?>
                                        -
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td class="text-center">
                                    <button id="hideMe" wire:click="selectRelay(<?php echo e($i); ?>)" type="button" class="btn btn-primary">Edit</button>
                                </td>
                            </tr>
                        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
        <!--[if BLOCK]><![endif]--><?php if($errors->any()): ?>
            <div class="pt-3 alert alert-danger">
                <ul>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="pt-3">
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            </div>
        <?php elseif(session()->has('alert')): ?>
            <div class="pt-3">
                <div class="alert alert-danger">
                    <?php echo e(session('alert')); ?>

                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="card shadow mb-4">
            <div class="p-4">
                <form>
                    <div class="mb-3 row">
                        <label for="relayNumber" class="col-sm-2 col-form-label"><h2>Edit Relay</h2></label>
                        <div class="col-sm-1">
                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo e($selectedRelay); ?>

                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <!--[if BLOCK]><![endif]--><?php for($i = 0; $i < 6; $i++): ?>
                                    <a wire:click="selectRelay(<?php echo e($i); ?>)" class="dropdown-item" href="#"><?php echo e($i+1); ?></a>
                                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <input type="number" wire:model="selectedRelay" hidden required>
                        </div>
                    </div>
                    <!--[if BLOCK]><![endif]--><?php if($selectedRelay != null): ?>
                        <div class="mb-3 row">
                            <label for="relayLabel" class="col-sm-2 col-form-label">Nama Perangkat</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" wire:model="selectedLabel" required>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="automationType" class="col-sm-2 col-form-label">Jenis</label>
                            <div class="col-sm-1">
                                <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <!--[if BLOCK]><![endif]--><?php switch($selectedType):
                                        case (2): ?>
                                            Suhu
                                            <?php break; ?>
                                        <?php case (3): ?>
                                            Cahaya
                                            <?php break; ?>
                                        <?php case (1): ?>
                                            Waktu
                                            <?php break; ?>
                                        <?php default: ?>
                                    <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a wire:click="selectType(2)" class="dropdown-item" href="#">Suhu</a>
                                    <a wire:click="selectType(3)" class="dropdown-item" href="#">Cahaya</a>
                                    <a wire:click="selectType(1)" class="dropdown-item" href="#">Waktu</a>
                                </div>
                                <input type="text" wire:model="selectedType" hidden required>
                            </div>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($selectedType == 2): ?>
                            <div class="mb-3 row">
                                <label for="relayTempThreshold" class="col-sm-2 col-form-label">Batas</label>
                                <div class="col-sm-1">
                                    <input type="text" class="text-center form-control" wire:model="tempThresholdInput" required>
                                </div>
                                <div>
                                    °C
                                </div>
                            </div>
                        <?php elseif($selectedType == 3): ?>
                            <div class="mb-3 row">
                                <label for="ldrThresholdInput" class="col-sm-2 col-form-label">Batas</label>
                                <div class="col-sm-1">
                                    <input type="text" class="text-center form-control" wire:model="ldrThresholdInput" required>
                                </div>
                                <div class="col-sm-1">
                                    %
                                </div>
                            </div>
                        <?php elseif($selectedType == 1): ?>
                            <div class="mb-3 row">
                                <label for="relayOnHour" class="col-sm-2 col-form-label">ON</label>
                                <div class="col-sm-1">
                                    <input type="text" class="text-center form-control" wire:model="onHourInput" required>
                                </div>
                                <div class="font-weight-bold">:</div>
                                <div class="col-sm-1">
                                    <input type="text" class="text-center form-control" wire:model="onMinuteInput" required>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="relayOffHour" class="col-sm-2 col-form-label">OFF</label>
                                <div class="col-sm-1">
                                    <input type="text" class="text-center form-control" wire:model="offHourInput" required>
                                </div>
                                <div class="font-weight-bold">:</div>
                                <div class="col-sm-1">
                                    <input type="text" class="text-center form-control" wire:model="offMinuteInput" required>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($selectedType != null): ?>
                            <div class="row">
                                <label class="col-sm-2 col-form-label"></label>
                                <div class="col-sm-10">
                                    <button type="button" class="btn btn-primary" name="submit" wire:click="editAutomation(<?php echo e($selectedRelay); ?>)">UPDATE</button>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </form>
                <br>
            </div>
        </div>
        <div class="card shadow mb-4">
            <div class="p-4">
                <!--[if BLOCK]><![endif]--><?php if($editPir != true): ?>
                    <h2>PIR</h2>
                <?php else: ?>
                    <h2>Edit PIR</h2>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <form>
                    <!--[if BLOCK]><![endif]--><?php if($editPir == true): ?>
                        <div class="mb-1 row">
                            <label for="relayOnHour" class="col-sm-2 col-form-label">Interval</label>
                            <div class="col-sm-1">
                                <input type="text" class="text-center form-control" wire:model="pirIntervalInput" required>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mb-1 row">
                            <label for="relayOnHour" class="col-sm-2 col-form-label">Interval</label>
                            <div class="col-sm-1">
                                <?php echo e($pirInterval); ?>

                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="mb-1 row">
                        <label for="name" class="col-sm-2 col-form-label">Jadwal PIR</label>
                        <div class="col-sm-1">
                            <!--[if BLOCK]><![endif]--><?php if($pirOnMinute !== null): ?>
                                <label class="switch mt-2">
                                    <input id="pirScheduleSwitch" type="checkbox" wire:click="selectPir()" <?php echo e($pirOrigin ? "checked" : ""); ?>>
                                    <span class="slider round"></span>
                                </label>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <!--[if BLOCK]><![endif]--><?php if($editPir == true): ?>
                        <div class="mb-1 row">
                            <label for="relayOnHour" class="col-sm-2 col-form-label">ON</label>
                            <div class="col-sm-1">
                                <input type="text" class="text-center form-control" wire:model="pirOnHourInput" required>
                            </div>
                            <div class="font-weight-bold">:</div>
                            <div class="col-sm-1">
                                <input type="text" class="text-center form-control" wire:model="pirOnMinInput" required>
                            </div>
                        </div>
                        <div class="mb-1 row">
                            <label for="relayOffHour" class="col-sm-2 col-form-label">OFF</label>
                            <div class="col-sm-1">
                                <input type="text" class="text-center form-control" wire:model="pirOffHourInput" required>
                            </div>
                            <div class="font-weight-bold">:</div>
                            <div class="col-sm-1">
                                <input type="text" class="text-center form-control" wire:model="pirOffMinInput" required>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mb-1 row">
                            <label for="relayOnHour" class="col-sm-2 col-form-label">ON</label>
                            <div class="col-sm-1">
                                <?php echo e($pirOn); ?>

                            </div>
                        </div>
                        <div class="mb-1 row">
                            <label for="relayOffHour" class="col-sm-2 col-form-label">OFF</label>
                            <div class="col-sm-1">
                                <?php echo e($pirOff); ?>

                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($editPir != true): ?>
                        <div class="mb-1 row">
                            <div class="mr-3">
                                <button type="button" class="btn btn-primary" name="submit" wire:click="editingPir(1)">EDIT</button>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mb-1 row">
                            <div class="mr-3">
                                <button type="button" class="btn btn-primary" name="submit" wire:click="storePir()">SIMPAN</button>
                            </div>
                            <div>
                                <button type="button" class="btn btn-danger" name="submit" wire:click="editingPir(0)">BATAL</button>
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </form>
            </div>
        </div>
    <?php else: ?>
    <div>Device belum terhubung, silakan hubungi admin</div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\smart-kos\resources\views/livewire/automation.blade.php ENDPATH**/ ?>