<div class="container mb-3 p-3 bg-white shadow-sm rounded">
    
    <div class="p-3">
        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="pt-3">
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($errors->any()): ?>
            <div class="pt-3 alert alert-danger">
                <ul>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($isEditing == false): ?>
            <h2>Profil</h2>
            <h5 class="mt-4 row">
                <label class="col-sm-1">Nama</label>
                <div class="col">
                    : <?php echo e($startName); ?>

                </div>
            </h5>
            <h5 class="row">
                <label class="col-sm-1">Email</label>
                <div class="col">
                    : <?php echo e(preg_replace("/(?!^).(?!$)/", "*", $startEmail)); ?>

                </div>
            </h5>
            
            <div class="mt-3">
                <button wire:click="edit(true)" class="btn btn-primary">Edit</button>
            </div>
        <?php else: ?>
            <h2>Edit Profil</h2>
            <form>
                <?php echo csrf_field(); ?>
                <div class="mt-4 form-group">
                    <label for="name" class="col-form-label">Nama</label>
                    <input type="text" class="form-control" id="name" wire:model="name" required>
                </div>
                <div class="form-group">
                    <label for="email" class="col-form-label">Email</label>
                    <input type="email" class="form-control" id="email" wire:model="email" required>
                </div>
                <div class="form-group">
                    <label for="password" class="col-form-label">Password</label>
                    <input type="password" class="form-control" id="password" wire:model="password">
                </div>
                <div class="form-group">
                    <label for="password_confirmation" class="col-form-label">Konfirmasi Password</label>
                    <input type="password" class="form-control" id="password_confirmation" wire:model="password_confirmation">
                </div>
                <div class="mt-3">
                    <button wire:click="edit(false)" type="reset" class="btn btn-danger">Batal</button>
                    <button wire:click="saveData()" name="submit" type="button" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\smart-kos\resources\views/livewire/user-profile.blade.php ENDPATH**/ ?>