
<div class="container-fluid">
    
    
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        
    </div>
        
    <!--[if BLOCK]><![endif]--><?php if(session()->has('danger')): ?>
        <div class="">
            <div class="alert alert-danger">
                <?php echo e(session('danger')); ?>

            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
    <div class="row">
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Konsumsi Listrik (Bulan Ini)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo e(number_format((float)$energy, 6, ',', '')); ?>

                                kWh
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Tagihan Listrik (Bulan Ini)</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                Rp
                                <?php echo e(number_format($roomBill, 2, ',', '.')); ?>

                                
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Penggunaan Listrik Saat Ini
                            </div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo e(number_format((float)$apparentPower, 2, ',', '')); ?> / <?php echo e($maxPower); ?> VA</div>
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Akses Listrik</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($electricAccess ? "Terhubung" : "Terputus"); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-comments fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">

        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Suhu</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="temperature">
                                <?php echo e($temperature); ?>

                                °C
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Kelembapan</div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                        <?php echo e($humidity); ?>

                                        %
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="progress progress-sm mr-2">
                                        <div class="progress-bar bg-info" role="progressbar"
                                            style="width: <?php echo e($humidity); ?>%" aria-valuenow="50" aria-valuemin="0"
                                            aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Intensitas Cahaya</div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                        <?php echo e($ldr); ?> %
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="progress progress-sm mr-2">
                                        <div class="progress-bar bg-info" role="progressbar"
                                            style="width: <?php echo e($ldr); ?>%" aria-valuenow="50" aria-valuemin="0"
                                            aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Keberadaan Orang</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo e($pir ? "Ada" : "Kosong"); ?>

                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-comments fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">

        
        <div class="col-xl col-lg">
            <div class="card shadow mb-4">
                
                <div
                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Konsumsi Listrik (Hari Ini)</h6>
                    <div class="dropdown no-arrow">
                        <a href="user/history" role="button">
                            
                            Riwayat
                        </a>
                        
                    </div>
                </div>

                
                <div class="card-body">
                    <div wire:ignore class="chart-area">
                        <canvas id="myChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Perangkat Elektronik</h6>
                    <div class="dropdown no-arrow">
                        <a href="user/automation" role="button">Edit Automasi</a>
                    </div>
                </div>
                <div class="card-body pt-2 pb-3">
                    <table>
                        <thead>
                            <tr>
                                <th class="col- p-0 pr-2 text-left">No.</th>
                                <th class="col-xl text-left p-0">Perangkat</th>
                                <th class="col-sm text-left p-1">Power</th>
                                <th class="col-sm text-center p-2">Automasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php if($deviceId): ?>
                                <!--[if BLOCK]><![endif]--><?php for($i = 0; $i < 6; $i++): ?>
                                    <tr>
                                        <td class="text-left"><?php echo e($i+1); ?></td>
                                        <td class="text-left"><?php echo e($relayLabel[$i]); ?></td>
                                        <td class="text-center">
                                            <!--[if BLOCK]><![endif]--><?php if($relayPir[$i] == 1 && $pir == 0): ?>
                                                <label class="switch mt-2 justify-content-center" wire:click="powerSwitch(<?php echo e($i); ?>, 0)">
                                                    <input type="checkbox" <?php echo e($relayStatus[$i] ? "checked" : ""); ?> disabled>
                                                    <span class="slider round"></span>
                                                </label>
                                            <?php else: ?>
                                                <label class="switch mt-2 justify-content-center">
                                                    <input type="checkbox" <?php echo e($relayStatus[$i] ? "checked" : ""); ?> wire:click="powerSwitch(<?php echo e($i); ?>, 1)">
                                                    <span class="slider round"></span>
                                                </label>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                            <td class="text-center">
                                                <label class="switch mt-2">
                                                    <input wire:click="automationSwitch(<?php echo e($i); ?>)" type="checkbox" <?php echo e($relayAuto[$i] ? "checked" : ""); ?>>
                                                    <span class="slider round"></span>
                                                </label>
                                            </td>
                                    </tr>
                                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if(session()->has('alert')): ?>
                <div wire:ignore>
                    <div wire:ignore class="alert alert-danger">
                        <?php echo e(session('alert')); ?>

                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    

    </div>

    
    

        
        

            
            

            
            
        

        
            
            

            
            
    
    

        <?php
        $__assetKey = '129992675-0';

        ob_start();
    ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;
            \Livewire\store($this)->push('assets', $__output, $__assetKey);
        }
    ?>

        <?php
        $__scriptKey = '129992675-1';
        ob_start();
    ?>
        <script>
            let ctx = document.getElementById("myChart");
            let datas = $wire.chartData;
            let labels = datas.map(item=>item.hour);
            let values = datas.map(item=>item.kwh);
            let myLineChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: "KWh",
                        lineTension: 0.3,
                        backgroundColor: "rgba(78, 115, 223, 0.05)",
                        borderColor: "rgba(78, 115, 223, 1)",
                        pointRadius: 3,
                        pointBackgroundColor: "rgba(78, 115, 223, 1)",
                        pointBorderColor: "rgba(78, 115, 223, 1)",
                        pointHoverRadius: 3,
                        pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
                        pointHoverBorderColor: "rgba(78, 115, 223, 1)",
                        pointHitRadius: 10,
                        pointBorderWidth: 2,
                        data: values,
                        xAxisID: 'xAxis',
                        yAxisID: 'yAxis',
                    }],
                },
                options: {
                    interaction: {
                        mode: 'x',
                        intersect: false,
                    },
                    maintainAspectRatio: false,
                    layout: {
                        padding: {
                            left: 0,
                            right: 0,
                            top: 0,
                            bottom: 0
                        }
                    },
                    scales: {
                        xAxis: {
                            // type: 'time',
                            grid: {
                                // display: false,
                                drawBorder: false
                            },
                            ticks: {
                                maxTicksLimit: 7
                            }
                        },
                        yAxis: {
                            ticks: {
                                maxTicksLimit: 6,
                                padding: 10,
                                // Include a dollar sign in the ticks
                                callback: function(value, index, ticks) {
                                    return parseFloat(value.toFixed(6));
                                }
                            },
                            grid: {
                                color: "rgb(234, 236, 244)",
                                zeroLineColor: "rgb(234, 236, 244)",
                                drawBorder: false,
                                tickBorderDash: [2],
                                zeroLineBorderDash: [2]
                            }
                        },
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            enabled: true,
                            backgroundColor: "rgba(255,255,255,1)",
                            bodyColor: '#858796',
                            titleMarginBottom: 10,
                            titleColor: '#6e707e',
                            // titleFont:{
                            //     size: 14,
                            // }
                            borderColor: 'rgba(221,223,235,1)',
                            borderWidth: 1,
                            padding: {
                                x: 15,
                                y: 15,
                            },
                            displayColors: false,
                            intersect: false,
                            mode: 'index',
                            caretPadding: 10,
                            callbacks: {
                                label: function(context) {
                                    let datasetLabel = context.dataset.label || '';
                                    return context.parsed.y + ' ' + datasetLabel;
                                }
                            }
                        },
                    },
                }
            });
        </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

</div>
<?php /**PATH C:\xampp\htdocs\smart-kos\resources\views/livewire/sensor-data.blade.php ENDPATH**/ ?>