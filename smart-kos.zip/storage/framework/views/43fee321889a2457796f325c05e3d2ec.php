<div class="container-fluid h-100">
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="pt-3">
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        </div>
    <?php elseif(session()->has('error')): ?>
        <div class="pt-3">
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="mb-3 p-3 bg-white shadow-sm rounded">
        <div class="p-3">
            <h2>
                Data Tagihan Listrik
            </h2>
            <!--[if BLOCK]><![endif]--><?php if($getDetail == true): ?>
                
                <div class="mt-3 row">
                    <label class="col-sm-1"><h5>Kos</h5></label>
                    <div class="col">
                        <h5>: <?php echo e($kosData[array_search($selectedKos, array_column($kosData, 'id'))]['name']); ?></h5>
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-1"><h5>Kamar</h5></label>
                    <div class="col">
                        <h5>: <?php echo e($roomData[array_search($selectedKos, array_column($kosData, 'id'))][array_search($selectedRoom, array_column($roomData[array_search($selectedKos, array_column($kosData, 'id'))], 'id'))]['name']); ?></h5>
                    </div>
                </div>
                <!--[if BLOCK]><![endif]--><?php if($mode > 0): ?>
                    <div class="row">
                        <label class="col-sm-1"><h5>Penghuni</h5></label>
                        <div class="col">
                            <h5>: <?php echo e($roomUser[array_search($selectedUser, array_column($roomUser, 'userId'))]['userName']); ?></h5>
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="row pl-4">
            <h5 wire:loading>Harap tunggu...</h5>
        </div>
        <table class="table table-hover">
            <!--[if BLOCK]><![endif]--><?php if($getDetail == false): ?>
                <thead>
                    <th scope="col">No</th>
                    <th scope="col">Nama Kos</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Kamar</th>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $kosData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kos => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($kos+1); ?></td>
                            <td><?php echo e($value['name']); ?></td>
                            <td><?php echo e($value['address']); ?></td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                        Kamar
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $roomData[$kos]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <button wire:click="getRoom(<?php echo e($data['id']); ?>, true, <?php echo e($value['id']); ?>)" type="button" class="dropdown-item">
                                                <!--[if BLOCK]><![endif]--><?php if($data['userId'] !== null): ?>
                                                    <?php echo e($data['name'] ." (". $data['userName'] .")"); ?>

                                                <?php else: ?>
                                                    <?php echo e($data['name'] ." (Kosong)"); ?>

                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            <?php elseif($getDetail == true): ?>
                <div class="row p-3">
                    <button
                    <?php if($mode == 0): ?>
                        wire:click="getRoom(0, false, 0)"
                    <?php elseif($mode == 1): ?>
                        wire:click="billDetail(0, 0)"
                    <?php elseif($mode == 2): ?>
                        wire:click="billDetail(0, 1)"
                    <?php elseif($mode == 3): ?>
                        wire:click="billDetail(0, 2)"
                    <?php elseif($mode == 4): ?>
                        wire:click="billDetail(0, 3)"
                    <?php endif; ?>
                    type="button" class="btn btn-secondary"
                >Kembali</button>
                </div>
                <thead>
                    <th scope="col">No</th>
                    <!--[if BLOCK]><![endif]--><?php if($mode == 0): ?>
                        <th scope="col">Penghuni</th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <th scope="col">Waktu</th>
                    <!--[if BLOCK]><![endif]--><?php if($mode > 0): ?>
                        <th scope="col" class="col-md-2 text-left">Tarif</th>
                        <th scope="col" class="col-md-2 text-left">KWh</th>
                        <th scope="col" class="col-md-2 text-left">Tagihan</th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($mode == 2): ?>
                        <th scope="col" class="col-md-2 text-left">Status</th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($mode != 4): ?>
                        <th scope="col"></th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php if($mode == 0): ?>
                        <!--[if BLOCK]><![endif]--><?php if($roomUser): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $roomUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($room+1); ?></td>
                                    <td><?php echo e($value['userName']); ?></td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($value['yearStart'] == $value['yearEnd']): ?>
                                            <?php echo e($value['yearStart']); ?>

                                        <?php else: ?>
                                            <?php echo e($value['yearStart'] .' - '. $value['yearEnd']); ?>

                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <button wire:click="billDetail(<?php echo e($value['userId']); ?>, 1)" wire:loading.attribute="disabled" type="button" class="btn btn-link btn-sm">
                                            <i class="bi bi-eye-fill">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                    <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>
                                                    <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7"/>
                                                </svg>
                                            </i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php elseif($mode == 1): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $yearlyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index+1); ?></td>
                                <td>
                                    <?php echo e($data['date']); ?>

                                </td>
                                <td>Rp <?php echo e(number_format($data['tariff'], 2, ',', '.')); ?></td>
                                <td><?php echo e(floatval($data['kwh']) .' KWh'); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($data['bill'] > 0): ?>
                                        <button wire:click="billDetail(<?php echo e((int)$data['date']); ?>, 2)" type="button" class="btn btn-outline-danger btn-sm"><?php echo e($data['bill'] ." Tunggakan"); ?></button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-outline-success btn-sm" disabled>Lunas</button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <button wire:click="billDetail(<?php echo e((int)$data['date']); ?>, 2)" wire:loading.attribute="disabled" type="button" class="btn btn-link btn-sm">
                                        <i class="bi bi-eye-fill">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>
                                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7"/>
                                            </svg>
                                        </i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php elseif($mode == 2): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $monthlyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index+1); ?></td>
                                <td>
                                    <?php echo e($data['date']); ?>

                                </td>
                                <td>Rp <?php echo e(number_format($data['tariff'], 2, ',', '.')); ?></td>
                                <td><?php echo e(floatval($data['kwh']) .' KWh'); ?></td>
                                <td>
                                    Rp <?php echo e(number_format($data['bill'], 2, ',', '.')); ?>

                                </td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if(date_format(date_create($currentYear .'-'. $currentMonth), 'm/Y') == $data['date']): ?>
                                        <button type="button" class="btn btn-outline-secondary btn-sm" disabled>Dalam Proses</button>
                                    <?php else: ?>
                                        <!--[if BLOCK]><![endif]--><?php if($data['paid'] == 0): ?>
                                            <button wire:click="verifyBill(<?php echo e((int)$data['date']); ?>)" wire:loading.attribute="disabled" type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#staticBackdrop">Menunggak</button>
                                            <button wire:click="verifyBill(<?php echo e((int)$data['date']); ?>)" wire:loading.attribute="disabled" type="button" class="btn btn-link btn-sm" data-toggle="modal" data-target="#staticBackdrop">
                                                <i class="bi bi-patch-check-fill">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-patch-check-fill" viewBox="0 0 16 16">
                                                        <path d="M10.067.87a2.89 2.89 0 0 0-4.134 0l-.622.638-.89-.011a2.89 2.89 0 0 0-2.924 2.924l.01.89-.636.622a2.89 2.89 0 0 0 0 4.134l.637.622-.011.89a2.89 2.89 0 0 0 2.924 2.924l.89-.01.622.636a2.89 2.89 0 0 0 4.134 0l.622-.637.89.011a2.89 2.89 0 0 0 2.924-2.924l-.01-.89.636-.622a2.89 2.89 0 0 0 0-4.134l-.637-.622.011-.89a2.89 2.89 0 0 0-2.924-2.924l-.89.01zm.287 5.984-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7 8.793l2.646-2.647a.5.5 0 0 1 .708.708"/>
                                                    </svg>
                                                </i>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-outline-success btn-sm" disabled>Lunas</button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <button wire:click="billDetail(<?php echo e((int)$data['date']); ?>, 3)" wire:loading.attribute="disabled" type="button" class="btn btn-link btn-sm">
                                        <i class="bi bi-eye-fill">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>
                                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7"/>
                                            </svg>
                                        </i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php elseif($mode == 3): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $dailyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index+1); ?></td>
                                <td>
                                    <?php echo e($data['date']); ?>

                                </td>
                                <td>Rp <?php echo e(number_format($data['tariff'], 2, ',', '.')); ?></td>
                                <td><?php echo e(floatval($data['kwh']) .' KWh'); ?></td>
                                <td>
                                    Rp <?php echo e(number_format($data['bill'], 2, ',', '.')); ?>

                                </td>
                                <td>
                                    <button wire:click="billDetail(<?php echo e((int)$data['date']); ?>, 4)" wire:loading.attribute="disabled" type="button" class="btn btn-link btn-sm">
                                        <i class="bi bi-eye-fill">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/>
                                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7"/>
                                            </svg>
                                        </i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php elseif($mode == 4): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $hourlyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index+1); ?></td>
                                <td>
                                    <?php echo e($data['date']); ?>

                                </td>
                                <td>Rp <?php echo e(number_format($data['tariff'], 2, ',', '.')); ?></td>
                                <td><?php echo e(floatval($data['kwh']) .' KWh'); ?></td>
                                <td>
                                    Rp <?php echo e(number_format($data['bill'], 2, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </table>
            <div wire:ignore.self class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">Konfirmasi Pembayaran</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            Konfirmasi pembayaran listrik ini?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-backdrop="static" data-dismiss="modal">Batal</button>
                            <button wire:click="confirmPayment()" type="button" class="btn btn-primary" data-dismiss="modal">Yakin</button>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\smart-kos\resources\views/livewire/electric-bill.blade.php ENDPATH**/ ?>