<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Smart Kos Energy Management with Internet of Things">
        <meta name="author" content="Ied Fajar Heryan">

        <title><?php echo e($title ?? 'Page Title'); ?></title>
    </head>
    <body>
        <?php echo e($slot); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\smart-kos\resources\views/layouts/app.blade.php ENDPATH**/ ?>